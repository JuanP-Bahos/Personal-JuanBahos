'use strict';
const MateriaPrima = require('../models/MateriaPrima');
const db = require('../../config/database');

class MateriaPrimaRepository {
  constructor() { this._store = db.materiasPrimas; }
  async findAll() { return this._store.map(MateriaPrima.fromDB); }
  async findById(id) {
    const d = this._store.find(m => m.id === id);
    return d ? MateriaPrima.fromDB(d) : null;
  }
  async update(id, data) {
    const idx = this._store.findIndex(m => m.id === id);
    if (idx === -1) return null;
    Object.assign(this._store[idx], data, { updatedAt: new Date().toISOString() });
    return MateriaPrima.fromDB(this._store[idx]);
  }
  async create(data) {
    const mp = new MateriaPrima(data);
    mp.recalcularEstado();
    this._store.push(mp.toJSON());
    return mp;
  }
}
module.exports = MateriaPrimaRepository;
