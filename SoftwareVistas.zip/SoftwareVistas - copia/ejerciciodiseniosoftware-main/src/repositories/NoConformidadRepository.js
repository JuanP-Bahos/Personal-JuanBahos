'use strict';
const NoConformidad = require('../models/NoConformidad');
const db = require('../../config/database');

class NoConformidadRepository {
  constructor() { this._store = db.noConformidades; }
  async findAll() { return this._store.map(NoConformidad.fromDB); }
  async findById(id) {
    const d = this._store.find(n => n.id === id);
    return d ? NoConformidad.fromDB(d) : null;
  }
  async findByLote(loteId) {
    return this._store.filter(n => n.loteId === loteId).map(NoConformidad.fromDB);
  }
  async create(data) {
    const nc = new NoConformidad(data);
    this._store.push(nc.toJSON());
    return nc;
  }
  async stats() {
    return {
      ncAbiertas:   this._store.filter(n => n.estado === 'abierta').length,
      ncEnRevision: this._store.filter(n => n.estado === 'en_revision').length,
      ncCerradas:   this._store.filter(n => n.estado === 'cerrada').length,
      lotesAuditados: db.lotes.length,
    };
  }
}
module.exports = NoConformidadRepository;
