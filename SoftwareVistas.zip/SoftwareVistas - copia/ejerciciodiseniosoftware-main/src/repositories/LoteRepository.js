/**
 * src/repositories/LoteRepository.js
 * Repositorio en memoria para LoteFarmaceutico.
 * Patrón: Repository Pattern.
 * Principio LSP: implementa contrato del repositorio correctamente.
 * Principio OCP: reemplazable por MySQLLoteRepository sin cambiar el resto.
 */
'use strict';

const LoteFarmaceutico = require('../models/LoteFarmaceutico');
const db               = require('../../config/database');

class LoteRepository {
  constructor() {
    this._store = db.lotes;
  }

  async findAll() {
    return this._store.map(LoteFarmaceutico.fromDB);
  }

  async findById(id) {
    const data = this._store.find(l => l.id === id);
    return data ? LoteFarmaceutico.fromDB(data) : null;
  }

  async create(data) {
    const lote = new LoteFarmaceutico(data);
    this._store.push(lote.toJSON());
    return lote;
  }

  async update(id, data) {
    const idx = this._store.findIndex(l => l.id === id);
    if (idx === -1) return null;
    Object.assign(this._store[idx], data, { updatedAt: new Date().toISOString() });
    return LoteFarmaceutico.fromDB(this._store[idx]);
  }

  async stats() {
    const all = this._store;
    return {
      lotesActivos:        all.filter(l => l.estado === 'en_produccion').length,
      pendienteLiberacion: all.filter(l => l.estado === 'pendiente_liberacion').length,
      liberados:           all.filter(l => l.estado === 'liberado').length,
      noConformidades:     db.noConformidades.filter(n => n.estado === 'abierta').length,
    };
  }
}

module.exports = LoteRepository;
