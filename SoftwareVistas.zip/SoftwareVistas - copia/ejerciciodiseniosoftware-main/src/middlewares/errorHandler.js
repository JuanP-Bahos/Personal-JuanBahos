'use strict';

function notFound(req, res, next) {
  const err = new Error(`Ruta no encontrada: ${req.originalUrl}`);
  err.status = 404;
  next(err);
}

function errorHandler(err, req, res, next) {
  const status  = err.status || err.statusCode || 500;
  const message = err.message || 'Error interno del servidor';

  // Si el layout ya fue inyectado o es llamada AJAX, json
  if (req.headers['accept'] && req.headers['accept'].includes('application/json')) {
    return res.status(status).json({ error: message });
  }

  res.status(status).render('error', {
    title: `Error ${status}`,
    status,
    message,
    stack: process.env.NODE_ENV !== 'production' ? err.stack : null,
  });
}

module.exports = { notFound, errorHandler };
