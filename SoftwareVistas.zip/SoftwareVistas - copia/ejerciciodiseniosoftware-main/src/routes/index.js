/**
 * src/routes/index.js — Router principal FarmaTrack
 * Composition Root: instancia e inyecta todas las dependencias.
 */
'use strict';

const express = require('express');
const router  = express.Router();
const db      = require('../../config/database');
const AppError = require('../utils/AppError');

// ── Repositorios ───────────────────────────────────────────────
const LoteRepository            = require('../repositories/LoteRepository');
const MateriaPrimaRepository    = require('../repositories/MateriaPrimaRepository');
const NoConformidadRepository   = require('../repositories/NoConformidadRepository');

// ── Servicios ──────────────────────────────────────────────────
const LoteService = require('../services/LoteService');

// ── Controladores ──────────────────────────────────────────────
const DashboardController  = require('../controllers/DashboardController');
const LoteController       = require('../controllers/LoteController');
const ProduccionController = require('../controllers/ProduccionController');

// ── Instancias (DI) ────────────────────────────────────────────
const loteRepo   = new LoteRepository();
const mpRepo     = new MateriaPrimaRepository();
const ncRepo     = new NoConformidadRepository();
const loteSvc    = new LoteService(loteRepo);

const dashCtrl   = new DashboardController(loteSvc);
const loteCtrl   = new LoteController(loteSvc);
const prodCtrl   = new ProduccionController(loteSvc);

// ══════════════════════════════════════════════════════════════
// RUTAS
// ══════════════════════════════════════════════════════════════

// Raíz → dashboard
router.get('/', (req, res) => res.redirect('/dashboard'));

// ── Dashboard ──────────────────────────────────────────────────
router.get('/dashboard', dashCtrl.index);

// ── Lotes ──────────────────────────────────────────────────────
router.get('/lotes',                loteCtrl.index);
router.get('/lotes/nuevo',          loteCtrl.newForm);
router.get('/lotes/liberacion',     loteCtrl.liberacion);
router.post('/lotes',               loteCtrl.create);
router.get('/lotes/:id',            loteCtrl.show);
router.get('/lotes/:id/firma',      loteCtrl.firma);
router.post('/lotes/:id/firma',     loteCtrl.procesarFirma);

// ── Producción ─────────────────────────────────────────────────
router.get('/produccion',                      (req, res) => res.redirect('/lotes'));
router.get('/produccion/:loteId',              prodCtrl.show);
router.post('/produccion/:loteId/paso',        prodCtrl.avanzar);

// ── Calidad ────────────────────────────────────────────────────
router.get('/calidad', async (req, res, next) => {
  try {
    const noConformidades = await ncRepo.findAll();
    const stats = await ncRepo.stats();
    res.render('calidad/index', {
      title: 'Control de Calidad',
      breadcrumb: [{ label: 'Calidad', url: '/calidad' }],
      noConformidades,
      stats,
    });
  } catch (err) { next(err); }
});

router.get('/calidad/no-conformidades', async (req, res, next) => {
  try {
    const noConformidades = await ncRepo.findAll();
    res.render('calidad/index', {
      title: 'No Conformidades',
      breadcrumb: [{ label: 'Calidad', url: '/calidad' }, { label: 'No Conformidades', url: '' }],
      noConformidades,
      stats: await ncRepo.stats(),
    });
  } catch (err) { next(err); }
});

router.get('/calidad/no-conformidades/nuevo', async (req, res, next) => {
  try {
    const lotes = await loteRepo.findAll();
    res.render('calidad/no-conformidades/new', {
      title: 'Nueva No Conformidad',
      breadcrumb: [{ label: 'Calidad', url: '/calidad' }, { label: 'Nueva NC', url: '' }],
      lotes,
      loteId: req.query.loteId || null,
      errores: [],
    });
  } catch (err) { next(err); }
});

router.post('/calidad/no-conformidades', async (req, res, next) => {
  try {
    const lotes = await loteRepo.findAll();
    const loteSeleccionado = lotes.find(l => l.id === req.body.loteIdSel);
    await ncRepo.create({
      loteId:           req.body.loteIdSel || req.body.loteId || '',
      numeroLote:       loteSeleccionado ? loteSeleccionado.numeroLote : '',
      tipo:             req.body.tipo,
      descripcion:      req.body.descripcion,
      accionCorrectiva: req.body.accionCorrectiva || '',
      responsable:      res.locals.currentUser ? res.locals.currentUser.nombre : 'Operario',
      prioridad:        req.body.prioridad || 'media',
      estado:           'abierta',
    });
    res.redirect('/calidad');
  } catch (err) { next(err); }
});

// ── Inventario ─────────────────────────────────────────────────
router.get('/inventario', async (req, res, next) => {
  try {
    const materias = await mpRepo.findAll();
    res.render('inventario/index', {
      title: 'Inventario',
      breadcrumb: [{ label: 'Inventario', url: '/inventario' }],
      materias,
    });
  } catch (err) { next(err); }
});

// ── Bitácora ───────────────────────────────────────────────────
router.get('/bitacora', (req, res) => {
  res.render('bitacora/index', {
    title: 'Bitácora INVIMA',
    breadcrumb: [{ label: 'Bitácora', url: '/bitacora' }],
    eventos: db.bitacora,
  });
});

// ── Reportes ───────────────────────────────────────────────────
router.get('/reportes', async (req, res, next) => {
  try {
    const lotes = await loteRepo.findAll();
    const total = lotes.length;
    const liberados = lotes.filter(l => l.estado === 'liberado').length;
    const resumen = {
      totalLotesMes:   total,
      tasaLiberacion:  total ? Math.round((liberados / total) * 100) : 0,
      totalNC:         db.noConformidades.length,
      tiempoPromedio:  '2.4',
      distribucion: [
        { label: 'En producción',      cantidad: lotes.filter(l => l.estado === 'en_produccion').length,        pct: total ? Math.round((lotes.filter(l=>l.estado==='en_produccion').length/total)*100) : 0,        color: '' },
        { label: 'Pend. liberación',   cantidad: lotes.filter(l => l.estado === 'pendiente_liberacion').length, pct: total ? Math.round((lotes.filter(l=>l.estado==='pendiente_liberacion').length/total)*100) : 0, color: 'progress__bar--yellow' },
        { label: 'Liberados',          cantidad: liberados,                                                     pct: total ? Math.round((liberados/total)*100) : 0,                                               color: '' },
        { label: 'No conformes',       cantidad: lotes.filter(l => l.estado === 'no_conforme').length,          pct: total ? Math.round((lotes.filter(l=>l.estado==='no_conforme').length/total)*100) : 0,          color: 'progress__bar--red' },
      ],
    };
    res.render('reportes/index', {
      title: 'Reportes',
      breadcrumb: [{ label: 'Reportes', url: '/reportes' }],
      resumen,
    });
  } catch (err) { next(err); }
});

// ── Auth (demo) ────────────────────────────────────────────────
router.get('/auth/login', (req, res) => {
  res.render('auth/login', {
    layout: 'layouts/auth',
    title: 'Iniciar sesión',
  });
});

router.get('/auth/demo', (req, res) => res.redirect('/dashboard'));

// ── Productos (compatibilidad original) ───────────────────────
const productosRouter = require('./productos');
router.use('/productos', productosRouter);

module.exports = router;
