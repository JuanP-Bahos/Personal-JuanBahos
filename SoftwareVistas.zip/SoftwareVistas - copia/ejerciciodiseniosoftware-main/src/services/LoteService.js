/**
 * src/services/LoteService.js
 * Capa de lógica de negocio para lotes farmacéuticos.
 * Principio SRP: solo contiene reglas de negocio de lotes.
 * Principio DIP: depende de la abstracción del repositorio.
 */
'use strict';

const AppError = require('../utils/AppError');
const db       = require('../../config/database');

class LoteService {
  constructor(loteRepository) {
    this._repo = loteRepository;
  }

  async obtenerTodos() {
    return this._repo.findAll();
  }

  async obtenerPorId(id) {
    if (!id) throw new AppError('ID requerido', 400);
    const lote = await this._repo.findById(id);
    if (!lote) throw new AppError(`Lote "${id}" no encontrado`, 404);
    return lote;
  }

  async obtenerStats() {
    return this._repo.stats();
  }

  async crear(data, usuarioActual) {
    if (!data.numeroLote) throw new AppError('El número de lote es requerido', 400);
    if (!data.producto)   throw new AppError('El producto es requerido', 400);
    if (!data.cantidad || parseInt(data.cantidad) < 1)
      throw new AppError('La cantidad debe ser mayor a 0', 400);

    const lote = await this._repo.create({
      ...data,
      estado:         'en_produccion',
      pasoActual:     1,
      totalPasos:     9,
      operarioId:     usuarioActual ? usuarioActual.id     : 'u-002',
      operarioNombre: usuarioActual ? usuarioActual.nombre : 'Juan Bahos',
    });

    this._log(lote.id, lote.operarioNombre, 'LOTE_CREADO',
      `Lote ${lote.numeroLote} creado para producción.`);
    return lote;
  }

  async avanzarPaso(loteId, paso, observaciones, nombreUsuario) {
    const lote = await this.obtenerPorId(loteId);
    lote.avanzarPaso();
    if (observaciones) lote.observaciones = observaciones;
    await this._repo.update(loteId, lote.toJSON());
    this._log(loteId, nombreUsuario, 'PASO_COMPLETADO',
      `Paso ${paso} completado.${observaciones ? ' Obs: ' + observaciones : ''}`);
    return lote;
  }

  async firmarLiberacion(loteId, usuario) {
    const lote = await this.obtenerPorId(loteId);
    if (lote.estado !== 'pendiente_liberacion')
      throw new AppError('El lote no está en estado "pendiente de liberación"', 400);
    lote.firmarLiberacion(usuario.nombre);
    await this._repo.update(loteId, lote.toJSON());
    this._log(loteId, usuario.nombre, 'FIRMA_LIBERACION',
      `Lote ${lote.numeroLote} liberado con firma electrónica.`);
    return lote;
  }

  generarChecklist(lote) {
    return [
      { descripcion: 'Todos los pasos del proceso completados',
        ok: lote.pasoActual >= lote.totalPasos },
      { descripcion: 'Sin no conformidades abiertas en el lote',
        ok: !db.noConformidades.some(n => n.loteId === lote.id && n.estado === 'abierta') },
      { descripcion: 'Batch record completo y firmado por operario',
        ok: lote.pasoActual >= lote.totalPasos },
      { descripcion: 'Resultados de laboratorio dentro de especificaciones',
        ok: lote.estado === 'pendiente_liberacion' },
      { descripcion: 'Certificados de análisis de materias primas vigentes',
        ok: true },
    ];
  }

  _log(loteId, usuario, accion, descripcion) {
    const { v4: uuidv4 } = require('uuid');
    db.bitacora.unshift({
      id: uuidv4(), loteId, usuario, accion, descripcion,
      fecha: new Date().toISOString(),
    });
  }
}

module.exports = LoteService;
