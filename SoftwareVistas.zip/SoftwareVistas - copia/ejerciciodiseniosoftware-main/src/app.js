/**
 * src/app.js — FarmaTrack
 * Punto de entrada. Bootstrap / Composition Root.
 */
'use strict';

const express        = require('express');
const path           = require('path');
const morgan         = require('morgan');
const methodOverride = require('method-override');
const expressLayouts = require('express-ejs-layouts');

const config = require('../config/app');
const router = require('./routes/index');
const { notFound, errorHandler } = require('./middlewares/errorHandler');

const app = express();

// ── Motor de plantillas ─────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));
app.use(expressLayouts);
app.set('layout', 'layouts/main');
app.set('layout extractScripts', true);
app.set('layout extractStyles', true);

// ── Middlewares ─────────────────────────────────────────────────────
app.use(morgan('dev'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride('_method'));
app.use(express.static(path.join(__dirname, '..', 'public')));

// Variables globales para todas las vistas
app.use((req, res, next) => {
  res.locals.appName     = config.app.name;
  res.locals.currentPath = req.path;

  // Usuario simulado: director técnico por defecto para el demo
  res.locals.currentUser = {
    id:     'u-001',
    nombre: 'David Peña',
    email:  'david.pena@farmatrack.co',
    rol:    'director_tecnico',
    cargo:  'Director Técnico',
  };
  next();
});

// ── Rutas ───────────────────────────────────────────────────────────
app.use('/', router);

// ── Errores ─────────────────────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

// ── Arranque ────────────────────────────────────────────────────────
const { port, host } = config.server;
app.listen(port, () => {
  console.log(`\n🚀 FarmaTrack corriendo en: http://${host}:${port}`);
  console.log(`📊 Dashboard: http://${host}:${port}/dashboard\n`);
});

module.exports = app;
