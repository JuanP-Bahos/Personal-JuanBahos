'use strict';
const { v4: uuidv4 } = require('uuid');

class MateriaPrima {
  constructor(data = {}) {
    this.id                  = data.id || uuidv4();
    this.codigo              = data.codigo || '';
    this.nombre              = data.nombre || '';
    this.proveedor           = data.proveedor || '';
    this.cantidadDisponible  = parseFloat(data.cantidadDisponible) || 0;
    this.unidad              = data.unidad || 'kg';
    this.stockMinimo         = parseFloat(data.stockMinimo) || 0;
    this.estado              = data.estado || 'disponible';
    this.fechaVencimiento    = data.fechaVencimiento || '';
    this.createdAt           = data.createdAt || new Date().toISOString();
    this.updatedAt           = data.updatedAt || new Date().toISOString();
  }

  recalcularEstado() {
    if (this.cantidadDisponible === 0) this.estado = 'agotado';
    else if (this.cantidadDisponible < this.stockMinimo) this.estado = 'bajo_stock';
    else this.estado = 'disponible';
    return this;
  }

  toJSON() { return { ...this }; }
  static fromDB(data) { return new MateriaPrima(data); }
}

module.exports = MateriaPrima;
