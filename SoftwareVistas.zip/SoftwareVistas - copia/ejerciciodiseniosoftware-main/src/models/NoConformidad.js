'use strict';
const { v4: uuidv4 } = require('uuid');

class NoConformidad {
  constructor(data = {}) {
    this.id               = data.id || uuidv4();
    this.loteId           = data.loteId || '';
    this.numeroLote       = data.numeroLote || '';
    this.tipo             = data.tipo || '';
    this.descripcion      = data.descripcion || '';
    this.accionCorrectiva = data.accionCorrectiva || '';
    this.responsable      = data.responsable || '';
    this.estado           = data.estado || 'abierta';
    this.prioridad        = data.prioridad || 'media';
    this.createdAt        = data.createdAt || new Date().toISOString();
    this.updatedAt        = data.updatedAt || new Date().toISOString();
  }
  toJSON() { return { ...this }; }
  static fromDB(data) { return new NoConformidad(data); }
}

module.exports = NoConformidad;
