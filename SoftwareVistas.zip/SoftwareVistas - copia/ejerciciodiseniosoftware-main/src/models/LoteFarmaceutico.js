/**
 * src/models/LoteFarmaceutico.js
 * Modelo de dominio — entidad central del sistema FarmaTrack.
 * Principio SRP: solo representa el estado del lote.
 * Principio OCP: se puede extender con nuevos estados sin modificar la clase.
 */
'use strict';
const { v4: uuidv4 } = require('uuid');

const ESTADOS_VALIDOS = ['en_produccion','pendiente_liberacion','liberado','no_conforme','en_cuarentena','rechazado'];

class LoteFarmaceutico {
  constructor(data = {}) {
    this.id               = data.id || uuidv4();
    this.numeroLote       = data.numeroLote || '';
    this.producto         = data.producto || '';
    this.forma            = data.forma || '';
    this.cantidad         = parseInt(data.cantidad) || 0;
    this.unidad           = data.unidad || 'unidades';
    this.estado           = data.estado || 'en_produccion';
    this.prioridad        = data.prioridad || 'media';
    this.pasoActual       = parseInt(data.pasoActual) || 1;
    this.totalPasos       = parseInt(data.totalPasos) || 9;
    this.operarioId       = data.operarioId || '';
    this.operarioNombre   = data.operarioNombre || '';
    this.fechaInicio      = data.fechaInicio || new Date().toISOString();
    this.fechaFinEstimada = data.fechaFinEstimada || '';
    this.fechaFin         = data.fechaFin || null;
    this.firmadoPor       = data.firmadoPor || null;
    this.fechaFirma       = data.fechaFirma || null;
    this.observaciones    = data.observaciones || '';
    this.createdAt        = data.createdAt || new Date().toISOString();
    this.updatedAt        = data.updatedAt || new Date().toISOString();
  }

  avanzarPaso() {
    if (this.pasoActual < this.totalPasos) {
      this.pasoActual++;
      this.updatedAt = new Date().toISOString();
    }
    if (this.pasoActual === this.totalPasos) {
      this.estado = 'pendiente_liberacion';
    }
    return this;
  }

  marcarNoConforme(observacion) {
    this.estado = 'no_conforme';
    this.observaciones = observacion || this.observaciones;
    this.updatedAt = new Date().toISOString();
    return this;
  }

  firmarLiberacion(firmadoPor) {
    this.estado = 'liberado';
    this.firmadoPor = firmadoPor;
    this.fechaFirma = new Date().toISOString();
    this.fechaFin = new Date().toISOString();
    this.updatedAt = new Date().toISOString();
    return this;
  }

  get porcentajeProgreso() {
    return Math.round((this.pasoActual / this.totalPasos) * 100);
  }

  toJSON() {
    return { ...this };
  }

  static fromDB(data) {
    return new LoteFarmaceutico(data);
  }
}

module.exports = LoteFarmaceutico;
