'use strict';

class ProduccionController {
  constructor(loteService) {
    this._svc = loteService;
    ['show','avanzar'].forEach(m => { this[m] = this[m].bind(this); });
  }

  async show(req, res, next) {
    try {
      const lote = await this._svc.obtenerPorId(req.params.loteId);
      const numeroPaso = parseInt(req.query.paso) || lote.pasoActual;
      const paso = this._svc.obtenerPasoInfo(numeroPaso);
      res.render('produccion/index', {
        title: `Producción — Paso ${numeroPaso}`,
        breadcrumb:[{label:'Producción',url:'/produccion'},{label:lote.numeroLote,url:''}],
        lote, paso,
      });
    } catch(err) { next(err); }
  }

  async avanzar(req, res, next) {
    try {
      const { observaciones, desviacion } = req.body;
      const usuario = res.locals.currentUser ? res.locals.currentUser.nombre : 'Operario';
      const lote = await this._svc.avanzarPaso(req.params.loteId, req.body.paso, observaciones, usuario);
      if (desviacion === 'si') {
        return res.redirect(`/calidad/no-conformidades/nuevo?loteId=${lote.id}`);
      }
      if (lote.estado === 'pendiente_liberacion') {
        return res.redirect(`/lotes/${lote.id}?flash=proceso_completado`);
      }
      res.redirect(`/produccion/${lote.id}`);
    } catch(err) { next(err); }
  }
}
module.exports = ProduccionController;
