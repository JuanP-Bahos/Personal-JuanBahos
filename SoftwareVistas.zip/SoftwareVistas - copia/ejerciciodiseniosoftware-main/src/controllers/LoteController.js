'use strict';
const AppError = require('../utils/AppError');
const db = require('../../config/database');

class LoteController {
  constructor(loteService) {
    this._svc = loteService;
    ['index','show','newForm','create','firma','procesarFirma','liberacion'].forEach(m => { this[m] = this[m].bind(this); });
  }

  async index(req, res, next) {
    try {
      const lotes = await this._svc.obtenerTodos();
      res.render('lotes/index', { title: 'Lotes', breadcrumb:[{label:'Lotes',url:'/lotes'}], lotes });
    } catch(err) { next(err); }
  }

  async show(req, res, next) {
    try {
      const lote = await this._svc.obtenerPorId(req.params.id);
      const bitacora = db.bitacora.filter(e => e.loteId === lote.id);
      res.render('lotes/show', { title: lote.numeroLote, breadcrumb:[{label:'Lotes',url:'/lotes'},{label:lote.numeroLote,url:`/lotes/${lote.id}`}], lote, bitacora });
    } catch(err) { next(err); }
  }

  async newForm(req, res, next) {
    try {
      res.render('lotes/new', { title: 'Nuevo Lote', breadcrumb:[{label:'Lotes',url:'/lotes'},{label:'Nuevo',url:'/lotes/nuevo'}], lote: {}, errores: [] });
    } catch(err) { next(err); }
  }

  async create(req, res, next) {
    try {
      const lote = await this._svc.crear(req.body, res.locals.currentUser);
      res.redirect(`/lotes/${lote.id}?flash=creado`);
    } catch(err) {
      if (err instanceof AppError) {
        return res.status(err.statusCode).render('lotes/new', { title:'Nuevo Lote', breadcrumb:[], lote: req.body, errores:[err.message] });
      }
      next(err);
    }
  }

  async firma(req, res, next) {
    try {
      const lote = await this._svc.obtenerPorId(req.params.id);
      if (lote.estado !== 'pendiente_liberacion') return res.redirect(`/lotes/${lote.id}`);
      const checklist = this._svc.generarChecklist(lote);
      res.render('lotes/firma', { title:`Firma — ${lote.numeroLote}`, breadcrumb:[{label:'Lotes',url:'/lotes'},{label:lote.numeroLote,url:`/lotes/${lote.id}`},{label:'Firma',url:''}], lote, checklist });
    } catch(err) { next(err); }
  }

  async procesarFirma(req, res, next) {
    try {
      const lote = await this._svc.firmarLiberacion(req.params.id, res.locals.currentUser || { nombre: 'David Peña' });
      res.redirect(`/lotes/${lote.id}?flash=firmado`);
    } catch(err) {
      if (err instanceof AppError) return res.redirect(`/lotes/${req.params.id}/firma?error=${encodeURIComponent(err.message)}`);
      next(err);
    }
  }

  async liberacion(req, res, next) {
    try {
      const lotes = await this._svc.obtenerTodos();
      const pendientes = lotes.filter(l => l.estado === 'pendiente_liberacion');
      res.render('lotes/index', { title:'Pendientes de liberación', breadcrumb:[{label:'Lotes',url:'/lotes'},{label:'Liberación',url:''}], lotes: pendientes });
    } catch(err) { next(err); }
  }
}
module.exports = LoteController;
