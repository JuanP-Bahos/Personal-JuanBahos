/**
 * src/controllers/DashboardController.js
 * Controlador del Dashboard principal de FarmaTrack.
 * Principio SRP: solo orquesta la vista del dashboard.
 * Principio DIP: recibe el servicio inyectado.
 */
'use strict';

const db = require('../../config/database');

class DashboardController {
  constructor(loteService) {
    this._svc = loteService;
    this.index = this.index.bind(this);
  }

  async index(req, res, next) {
    try {
      // Lotes activos (en producción + pendientes)
      const todosLosLotes = await this._svc.obtenerTodos();
      const lotes = todosLosLotes.filter(l =>
        ['en_produccion', 'pendiente_liberacion'].includes(l.estado)
      );

      // Estadísticas generales
      const stats = await this._svc.obtenerStats();

      // Bitácora reciente (últimos 4 eventos)
      const bitacora = db.bitacora.slice(0, 4);

      // Alertas activas
      const alertas = [];
      if (stats.pendienteLiberacion > 0) {
        alertas.push({
          icono: '⏳',
          titulo: `${stats.pendienteLiberacion} lote(s) pendiente(s) de liberación`,
          descripcion: 'Requieren firma electrónica del Director Técnico.',
        });
      }
      if (stats.noConformidades > 0) {
        alertas.push({
          icono: '⚠️',
          titulo: `${stats.noConformidades} no conformidad(es) abierta(s)`,
          descripcion: 'Requieren acción correctiva según BPM.',
        });
      }
      const mpCriticas = db.materiasPrimas.filter(m => m.estado !== 'disponible');
      if (mpCriticas.length > 0) {
        alertas.push({
          icono: '📦',
          titulo: `${mpCriticas.length} materia(s) prima(s) con stock crítico`,
          descripcion: mpCriticas.map(m => m.nombre).join(' · '),
        });
      }

      res.render('dashboard/index', {
        title: 'Dashboard',
        breadcrumb: [{ label: 'Dashboard', url: '/dashboard' }],
        lotes,
        stats,
        alertas,
        bitacora,
      });

    } catch (err) {
      next(err);
    }
  }
}

module.exports = DashboardController;
