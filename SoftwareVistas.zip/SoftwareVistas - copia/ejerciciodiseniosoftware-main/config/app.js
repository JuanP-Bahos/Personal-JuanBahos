/**
 * config/app.js
 * Configuración centralizada de FarmaTrack.
 * Principio: Single Responsibility - solo gestiona configuración.
 */

'use strict';

const config = {
  server: {
    port: process.env.PORT || 3000,
    host: process.env.HOST || 'localhost',
  },
  app: {
    name: 'FarmaTrack',
    version: '1.0.0',
    env: process.env.NODE_ENV || 'development',
    description: 'Sistema de Gestión de Lotes Farmacéuticos',
  },
  pagination: {
    defaultLimit: 10,
    maxLimit: 100,
  },
};

module.exports = config;
