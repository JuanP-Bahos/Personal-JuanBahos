/**
 * config/database.js
 * Base de datos en memoria para FarmaTrack.
 * En producción se reemplazaría por PostgreSQL / MySQL via ORM.
 */

'use strict';

const { v4: uuidv4 } = require('uuid');

const now = new Date().toISOString();
const hace1dia = new Date(Date.now() - 86400000).toISOString();
const hace2dias = new Date(Date.now() - 172800000).toISOString();
const hace3dias = new Date(Date.now() - 259200000).toISOString();

const db = {
  // ── Usuarios ────────────────────────────────────────────
  usuarios: [
    {
      id: 'u-001',
      nombre: 'David Peña',
      email: 'david.pena@farmatrack.co',
      rol: 'director_tecnico',
      cargo: 'Director Técnico',
      activo: true,
      createdAt: hace3dias,
    },
    {
      id: 'u-002',
      nombre: 'Juan Bahos',
      email: 'juan.bahos@farmatrack.co',
      rol: 'operario',
      cargo: 'Operario de Producción',
      activo: true,
      createdAt: hace3dias,
    },
    {
      id: 'u-003',
      nombre: 'Sergio Velandia',
      email: 'sergio.velandia@farmatrack.co',
      rol: 'calidad',
      cargo: 'Analista de Calidad',
      activo: true,
      createdAt: hace3dias,
    },
  ],

  // ── Lotes farmacéuticos ─────────────────────────────────
  lotes: [
    {
      id: 'lot-001',
      numeroLote: 'LOT-2025-001',
      producto: 'Amoxicilina 500mg',
      forma: 'Cápsula',
      cantidad: 50000,
      unidad: 'unidades',
      estado: 'en_produccion',
      prioridad: 'alta',
      fechaInicio: hace2dias,
      fechaFinEstimada: new Date(Date.now() + 86400000).toISOString(),
      operarioId: 'u-002',
      operarioNombre: 'Juan Bahos',
      pasoActual: 4,
      totalPasos: 9,
      observaciones: 'Lote prioritario para exportación.',
      createdAt: hace2dias,
      updatedAt: now,
    },
    {
      id: 'lot-002',
      numeroLote: 'LOT-2025-002',
      producto: 'Ibuprofeno 400mg',
      forma: 'Tableta',
      cantidad: 100000,
      unidad: 'unidades',
      estado: 'pendiente_liberacion',
      prioridad: 'media',
      fechaInicio: hace3dias,
      fechaFinEstimada: now,
      operarioId: 'u-002',
      operarioNombre: 'Juan Bahos',
      pasoActual: 9,
      totalPasos: 9,
      observaciones: 'Pendiente firma Director Técnico.',
      createdAt: hace3dias,
      updatedAt: now,
    },
    {
      id: 'lot-003',
      numeroLote: 'LOT-2025-003',
      producto: 'Metformina 850mg',
      forma: 'Tableta',
      cantidad: 75000,
      unidad: 'unidades',
      estado: 'liberado',
      prioridad: 'baja',
      fechaInicio: hace3dias,
      fechaFin: hace1dia,
      fechaFinEstimada: hace1dia,
      operarioId: 'u-002',
      operarioNombre: 'Juan Bahos',
      pasoActual: 9,
      totalPasos: 9,
      firmadoPor: 'David Peña',
      fechaFirma: hace1dia,
      observaciones: 'Lote liberado sin observaciones.',
      createdAt: hace3dias,
      updatedAt: hace1dia,
    },
    {
      id: 'lot-004',
      numeroLote: 'LOT-2025-004',
      producto: 'Loratadina 10mg',
      forma: 'Tableta',
      cantidad: 30000,
      unidad: 'unidades',
      estado: 'no_conforme',
      prioridad: 'alta',
      fechaInicio: hace2dias,
      fechaFinEstimada: now,
      operarioId: 'u-002',
      operarioNombre: 'Juan Bahos',
      pasoActual: 6,
      totalPasos: 9,
      observaciones: 'Desviación detectada en control microbiológico.',
      createdAt: hace2dias,
      updatedAt: now,
    },
  ],

  // ── Materias primas (inventario) ────────────────────────
  materiasPrimas: [
    {
      id: 'mp-001',
      codigo: 'MP-AMX-001',
      nombre: 'Amoxicilina trihidrato',
      proveedor: 'Química Internacional S.A.',
      cantidadDisponible: 500,
      unidad: 'kg',
      stockMinimo: 100,
      estado: 'disponible',
      fechaVencimiento: new Date(Date.now() + 180 * 86400000).toISOString(),
      createdAt: hace3dias,
      updatedAt: now,
    },
    {
      id: 'mp-002',
      codigo: 'MP-IBU-001',
      nombre: 'Ibuprofeno base',
      proveedor: 'FarmaQuim Ltda.',
      cantidadDisponible: 80,
      unidad: 'kg',
      stockMinimo: 150,
      estado: 'bajo_stock',
      fechaVencimiento: new Date(Date.now() + 90 * 86400000).toISOString(),
      createdAt: hace3dias,
      updatedAt: now,
    },
    {
      id: 'mp-003',
      codigo: 'MP-MET-001',
      nombre: 'Metformina clorhidrato',
      proveedor: 'Síntesis Pharma',
      cantidadDisponible: 300,
      unidad: 'kg',
      stockMinimo: 100,
      estado: 'disponible',
      fechaVencimiento: new Date(Date.now() + 270 * 86400000).toISOString(),
      createdAt: hace3dias,
      updatedAt: now,
    },
    {
      id: 'mp-004',
      codigo: 'MP-EXC-001',
      nombre: 'Lactosa monohidrato',
      proveedor: 'Excipientes del Valle',
      cantidadDisponible: 0,
      unidad: 'kg',
      stockMinimo: 200,
      estado: 'agotado',
      fechaVencimiento: new Date(Date.now() + 365 * 86400000).toISOString(),
      createdAt: hace3dias,
      updatedAt: now,
    },
  ],

  // ── No conformidades ─────────────────────────────────────
  noConformidades: [
    {
      id: 'nc-001',
      loteId: 'lot-004',
      numeroLote: 'LOT-2025-004',
      tipo: 'desviacion_proceso',
      descripcion: 'Temperatura de mezclado fuera de rango especificado (±2°C sobre límite superior).',
      accionCorrectiva: 'Revisión de sistema de control de temperatura. Reentrenamiento de operario.',
      responsable: 'Juan Bahos',
      estado: 'abierta',
      prioridad: 'alta',
      createdAt: now,
      updatedAt: now,
    },
  ],

  // ── Bitácora de eventos (audit trail) ───────────────────
  bitacora: [
    { id: 'b-001', loteId: 'lot-003', usuario: 'David Peña', accion: 'FIRMA_LIBERACION', descripcion: 'Lote LOT-2025-003 liberado con firma electrónica.', fecha: hace1dia },
    { id: 'b-002', loteId: 'lot-002', usuario: 'Juan Bahos', accion: 'PASO_COMPLETADO', descripcion: 'Paso 9 completado: Control de Calidad Final.', fecha: now },
    { id: 'b-003', loteId: 'lot-004', usuario: 'Juan Bahos', accion: 'NO_CONFORMIDAD', descripcion: 'Registrada no conformidad NC-001 por desviación de temperatura.', fecha: now },
    { id: 'b-004', loteId: 'lot-001', usuario: 'Juan Bahos', accion: 'PASO_COMPLETADO', descripcion: 'Paso 4 completado: Granulación.', fecha: now },
  ],

  // ── Productos (compatibilidad con CRUD original) ─────────
  productos: [],
};

module.exports = db;
