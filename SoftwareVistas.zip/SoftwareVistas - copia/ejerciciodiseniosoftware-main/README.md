# 📦 CRUD Express EJS — Arquitectura MVC + SOLID

Proyecto monolítico completo con **Express.js** + **EJS**, implementando CRUD de Productos con arquitectura limpia, patrones arquitectónicos y principios SOLID.

---

## 🚀 Inicio rápido

```bash
npm install
npm run dev       # Modo desarrollo con nodemon
npm start         # Modo producción
npm test          # Ejecutar tests
```

Abre: [http://localhost:3000](http://localhost:3000)

---

## 🏗️ Arquitectura y estructura

```
proyecto-crud/
├── config/
│   ├── app.js               # Configuración centralizada
│   └── database.js          # Capa de datos (in-memory / reemplazable)
│
├── src/
│   ├── app.js               # Bootstrap de la aplicación (Composition Root)
│   │
│   ├── models/
│   │   └── Producto.js      # Modelo de dominio (entidad)
│   │
│   ├── repositories/
│   │   ├── IProductoRepository.js   # Interfaz / contrato (abstracción)
│   │   └── ProductoRepository.js    # Implementación concreta (in-memory)
│   │
│   ├── services/
│   │   └── ProductoService.js       # Lógica de negocio
│   │
│   ├── controllers/
│   │   └── ProductoController.js    # Manejo de HTTP, orquestación
│   │
│   ├── routes/
│   │   ├── index.js                 # Router principal
│   │   └── productos.js             # Rutas RESTful del recurso
│   │
│   ├── middlewares/
│   │   ├── errorHandler.js          # Manejo global de errores
│   │   └── flashMessages.js         # Mensajes de retroalimentación
│   │
│   ├── validators/
│   │   └── productoValidator.js     # Reglas de validación (express-validator)
│   │
│   └── utils/
│       └── AppError.js              # Error personalizado de dominio
│
├── views/
│   ├── layouts/
│   │   └── main.ejs         # Layout base compartido
│   ├── productos/
│   │   ├── index.ejs        # Listado con estadísticas
│   │   ├── show.ejs         # Detalle de producto
│   │   ├── new.ejs          # Formulario de creación
│   │   └── edit.ejs         # Formulario de edición
│   └── error.ejs            # Página de error global
│
├── public/
│   ├── css/style.css        # Hoja de estilos completa
│   └── js/main.js           # JavaScript del cliente
│
└── tests/
    └── ProductoService.test.js  # Tests unitarios
```

---

## 🧩 Patrones arquitectónicos aplicados

| Patrón | Dónde | Propósito |
|---|---|---|
| **MVC** | controllers / views / models | Separación de presentación, lógica y datos |
| **Repository Pattern** | repositories/ | Abstrae la persistencia; fácil de cambiar la BD |
| **Service Layer** | services/ | Centraliza la lógica de negocio |
| **Dependency Injection** | routes/productos.js | Desacopla las capas |
| **Composition Root** | src/app.js + routes | Único lugar donde se ensamblan dependencias |
| **Front Controller** | routes/index.js | Punto de entrada único para el enrutamiento |

---

## ✅ Principios SOLID aplicados

### S — Single Responsibility
- `ProductoController` solo maneja HTTP.
- `ProductoService` solo contiene reglas de negocio.
- `ProductoRepository` solo gestiona persistencia.
- `AppError` solo encapsula errores de dominio.

### O — Open / Closed
- Agregar `MySQLProductoRepository` sin tocar `ProductoService`.
- Agregar nuevas reglas de validación sin cambiar el controlador.

### L — Liskov Substitution
- `ProductoRepository` puede reemplazar a `IProductoRepository` sin romper el sistema.

### I — Interface Segregation
- `IProductoRepository` define solo los métodos necesarios para el recurso Producto.

### D — Dependency Inversion
- `ProductoService` depende de `IProductoRepository` (abstracción), no de la implementación.
- Inyección de dependencias en el Composition Root (`routes/productos.js`).

---

## 🔄 Rutas RESTful

| Método | Ruta | Acción |
|---|---|---|
| GET | `/productos` | Listar todos |
| GET | `/productos/nuevo` | Formulario crear |
| POST | `/productos` | Crear |
| GET | `/productos/:id` | Detalle |
| GET | `/productos/:id/editar` | Formulario editar |
| PUT | `/productos/:id` | Actualizar |
| DELETE | `/productos/:id` | Eliminar |

> PUT y DELETE se simulan con `method-override` vía query `?_method=PUT`.

---

## 🔌 Cambiar a base de datos real

Solo necesitas crear una nueva implementación del repositorio:

```js
// src/repositories/MySQLProductoRepository.js
class MySQLProductoRepository extends IProductoRepository {
  async findAll() { /* SELECT * FROM productos */ }
  async findById(id) { /* SELECT * FROM productos WHERE id = ? */ }
  // ...
}
```

Y cambiar en `routes/productos.js`:
```js
// const productoRepository = new ProductoRepository();      // in-memory
const productoRepository = new MySQLProductoRepository();    // MySQL
```

El resto de la aplicación no cambia. ✅

---

## 🧪 Tests

```bash
npm test
```

Los tests del `ProductoService` usan un repositorio **mock**, demostrando que la lógica de negocio es completamente independiente de la persistencia.

---

## 📦 Dependencias

| Paquete | Uso |
|---|---|
| `express` | Framework web |
| `ejs` | Motor de plantillas |
| `express-ejs-layouts` | Sistema de layouts compartidos |
| `method-override` | PUT/DELETE desde formularios HTML |
| `express-validator` | Validación de entradas |
| `morgan` | Logger HTTP |
| `uuid` | Generación de IDs únicos |
| `nodemon` | Hot-reload en desarrollo |
| `jest` + `supertest` | Testing |
